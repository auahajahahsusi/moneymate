const tg=window.Telegram?.WebApp;tg?.ready();tg?.expand();
const initData=tg?.initData||"";const headers={"Content-Type":"application/json","X-Telegram-Init-Data":initData};
let kind="expense",currency="RUB",transactions=[],goals=[],recurring=[],wallets=[],limits=[],accessState=null;
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat("ru-RU",{style:"currency",currency,maximumFractionDigits:2}).format(Number(n||0));
const today=()=>new Date().toISOString().slice(0,10);
function notify(msg){$("notice").textContent=msg;$("notice").classList.remove("hidden");setTimeout(()=>$("notice").classList.add("hidden"),5000)}
async function api(path,opts={}){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),30000);let r;try{r=await fetch(path,{...opts,signal:controller.signal,cache:"no-store",headers:{...headers,...opts.headers}})}catch(err){if(err.name==="AbortError")throw new Error("Сервер не ответил за 30 секунд. Нажми «Повторить проверку»; если повторяется — проверь Render Logs.");throw new Error("Не удалось связаться с сервером: "+(err.message||"ошибка сети"))}finally{clearTimeout(timer)}let data={};try{data=await r.json()}catch{}if(!r.ok)throw new Error(data.detail||("Ошибка сервера HTTP "+r.status));return data}
function openModal(id){$(id).classList.remove("hidden")}function closeModal(id){$(id).classList.add("hidden")}
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab,.panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.tab).classList.add("active")});
function showTab(name){document.querySelector(`.tab[data-tab="${name}"]`).click()}
function renderTransactions(){const el=$("transactions");if(!transactions.length){el.innerHTML='<div class="empty card">Операций пока нет. Нажми ＋, чтобы добавить первую.</div>';return}
el.innerHTML=transactions.map(t=>`<div class="tx"><div class="tx-icon ${t.kind==='expense'?'out':''}">${t.kind==='income'?'↗':'↘'}</div><div class="tx-main"><b>${esc(t.category)}</b><small>${esc(t.note||t.happened_at)} · ${t.happened_at}</small></div><div class="tx-amount ${t.kind==='expense'?'out':''}">${t.kind==='income'?'+':'−'}${money(t.amount)}</div><button class="delete" data-del="${t.id}" aria-label="Удалить">×</button></div>`).join("");
el.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{if(confirm("Удалить эту операцию?")){try{await api(`/api/transactions/${b.dataset.del}`,{method:"DELETE"});await refresh()}catch(e){notify(e.message)}}})}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderGoals(){const el=$("goalsList");if(!goals.length){el.innerHTML='<div class="empty card">Создай первую цель накоплений</div>';return}
el.innerHTML=goals.map(g=>{let p=Math.min(100,g.saved/g.target*100);return `<div class="goal"><div class="goal-top"><div><h3>${esc(g.title)}</h3><p>${g.deadline?'Цель до '+g.deadline:'Накопительная цель'}</p></div><button class="delete" data-gdel="${g.id}">×</button></div><div class="track"><i style="width:${p}%"></i></div><div class="goal-foot"><span>${money(g.saved)} из ${money(g.target)} · ${p.toFixed(0)}%</span><button class="small-btn" data-addgoal="${g.id}">＋ Пополнить</button></div></div>`}).join("");
el.querySelectorAll("[data-gdel]").forEach(b=>b.onclick=async()=>{if(confirm("Удалить цель?")){try{await api(`/api/goals/${b.dataset.gdel}`,{method:"DELETE"});await refresh()}catch(e){notify(e.message)}}});
el.querySelectorAll("[data-addgoal]").forEach(b=>b.onclick=()=>{$("contributeId").value=b.dataset.addgoal;openModal("contributeModal")})}
async function renderSummary(){const s=await api("/api/summary");currency="RUB";$("balance").textContent=money(s.balance);$("income").textContent=money(s.income);$("expense").textContent=money(s.expense);$("monthLabel").textContent=s.month;
const fh=s.financial_health||{score:1,parts:{},hint:"Добавь операции."};$("healthScore").textContent=fh.score;$("healthBar").style.width=fh.score+"%";$("healthRing").style.setProperty("--score",fh.score);$("healthLabel").textContent=fh.score>=80?"Отлично":fh.score>=60?"Хорошо":fh.score>=40?"Есть что улучшить":"Нужно внимание";$("healthHint").textContent=fh.hint;$("healthParts").innerHTML=Object.entries(fh.parts||{}).map(([k,v])=>`<span>${esc(k)} <b>${v}</b></span>`).join("");$("needsPct").textContent=s.settings.needs+"%";$("wantsPct").textContent=s.settings.wants+"%";$("savingsPct").textContent=s.settings.savings+"%";$("needsBar").style.width=s.settings.needs+"%";$("wantsBar").style.width=s.settings.wants+"%";$("savingsBar").style.width=s.settings.savings+"%";
const palette=["#55d69a","#b99aff","#f3c96b","#ff7b83","#69aef5","#f39b62","#70d6c5","#d58acb"];const total=s.categories.reduce((a,x)=>a+Number(x.total||0),0);let cursor=0;const stops=s.categories.map((x,i)=>{const start=cursor;cursor+=total?Number(x.total)/total*100:0;return `${palette[i%palette.length]} ${start}% ${cursor}%`}).join(",");$("categoryChart").classList.toggle("empty",!s.categories.length);$("categoryChart").innerHTML=s.categories.length?`<div class="donut-layout"><div class="donut" style="background:conic-gradient(${stops})"><div class="donut-hole"><b>${money(total)}</b><small>расходы</small></div></div><div class="donut-legend">${s.categories.map((x,i)=>`<div class="legend-row"><i style="background:${palette[i%palette.length]}"></i><span>${esc(x.category)}</span><b>${money(x.total)}</b><small>${total?Math.round(x.total/total*100):0}%</small></div>`).join("")}</div></div>`:"Добавь первую операцию — здесь появится аналитика";
$("currency").value="RUB · Российский рубль";$("needs").value=s.settings.needs;$("wants").value=s.settings.wants;$("savings").value=s.settings.savings}
const freqLabel={weekly:"еженедельно",monthly:"ежемесячно",yearly:"ежегодно"};
function renderRecurring(){const el=$("recurringList");if(!recurring.length){el.innerHTML='<div class="empty card">Регулярных платежей пока нет. Добавь зарплату, аренду или подписку.</div>';return}
el.innerHTML=recurring.map(p=>`<div class="recurring-item"><div class="tx-icon ${p.kind==="expense"?"out":""}">${p.kind==="income"?"↗":"↻"}</div><div class="tx-main"><b>${esc(p.category)} · ${money(p.amount)}</b><small>${freqLabel[p.frequency]} · следующая дата: ${p.next_date}${p.note?" · "+esc(p.note):""}</small><small class="${p.active?"status-on":"status-off"}">${p.active?"Активен":"На паузе"}</small></div><div class="recurring-actions"><button class="small-btn" data-toggle-rec="${p.id}">${p.active?"Пауза":"Включить"}</button><button class="delete" data-rdel="${p.id}">×</button></div></div>`).join("");
el.querySelectorAll("[data-toggle-rec]").forEach(b=>b.onclick=async()=>{try{await api(`/api/recurring/${b.dataset.toggleRec}`,{method:"PATCH"});await refresh()}catch(e){notify(e.message)}});
el.querySelectorAll("[data-rdel]").forEach(b=>b.onclick=async()=>{if(confirm("Удалить регулярный платёж?")){try{await api(`/api/recurring/${b.dataset.rdel}`,{method:"DELETE"});await refresh()}catch(e){notify(e.message)}}})}
async function renderCalendar(){const month=$("calendarMonth").value||today().slice(0,7);const d=await api(`/api/calendar?month=${month}`);const el=$("calendarEvents");if(!d.events.length){el.innerHTML='<div class="empty card">На этот месяц пока нет операций и запланированных платежей.</div>';return}d.events.sort((a,b)=>a.date.localeCompare(b.date));el.innerHTML=d.events.map(e=>`<div class="tx"><div class="tx-icon ${e.kind==='expense'?'out':''}">${e.source==='planned'?'◷':e.kind==='income'?'↗':'↘'}</div><div class="tx-main"><b>${esc(e.category)}</b><small>${e.date} · ${e.source==='planned'?'Запланировано':'Проведено'}</small></div><div class="tx-amount ${e.kind==='expense'?'out':''}">${e.kind==='income'?'+':'−'}${money(e.amount)}</div></div>`).join("")}
async function renderWallets(){wallets=await api('/api/wallets');const el=$("walletList");el.innerHTML=wallets.length?wallets.map(w=>`<div class="goal"><div class="goal-top"><div><h3>${esc(w.name)}</h3><p>${esc(w.kind)}</p></div><button class="delete" data-wdel="${w.id}">×</button></div><b>${money(w.balance)}</b></div>`).join(''):'<div class="empty card">Добавь карту, наличные или накопительный счёт.</div>';el.querySelectorAll('[data-wdel]').forEach(b=>b.onclick=async()=>{if(confirm('Удалить кошелёк?')){await api(`/api/wallets/${b.dataset.wdel}`,{method:'DELETE'});renderWallets()}})}
async function renderLimits(){limits=await api('/api/limits');const el=$("limitList");el.innerHTML=limits.length?limits.map(l=>{const pct=Math.min(100,l.spent/l.amount*100);return `<div class="goal"><div class="goal-top"><div><h3>${esc(l.category)}</h3><p>Потрачено ${money(l.spent)} из ${money(l.amount)}</p></div><button class="delete" data-ldel="${l.id}">×</button></div><div class="track"><i style="width:${pct}%;background:${pct>=100?'#ef4444':''}"></i></div><small>${pct.toFixed(0)}% лимита использовано</small></div>`}).join(''):'<div class="empty card">Лимитов пока нет.</div>';el.querySelectorAll('[data-ldel]').forEach(b=>b.onclick=async()=>{await api(`/api/limits/${b.dataset.ldel}`,{method:'DELETE'});renderLimits()})}
async function refresh(){[transactions,goals,recurring]=await Promise.all([api("/api/transactions"),api("/api/goals"),api("/api/recurring")]);await renderSummary();renderTransactions();renderGoals();renderRecurring();await Promise.all([renderWallets(),renderLimits(),renderCalendar()]);if(accessState?.plan==="premium")await loadPremiumInsights()}
const categoryOptions={expense:["Продукты","Жильё","Коммунальные услуги","Транспорт","Здоровье","Покупки","Одежда","Развлечения","Кафе и рестораны","Подписки","Образование","Путешествия","Другое"],income:["Зарплата","Фриланс","Бизнес","Подработка","Инвестиции","Подарок","Возврат средств","Проценты и кешбэк","Другое"]};
function updateCategoryOptions(selected=""){const select=$("category");const list=categoryOptions[kind];select.innerHTML=list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join("");if(selected&&list.includes(selected))select.value=selected}
function startTx(k="expense"){$("txForm").reset();kind=k;updateCategoryOptions();
$("newRecurring").onclick=()=>{$("recurringForm").reset();recurringKind="expense";$("recurringKind").value=recurringKind;$("recurringDate").value=today();document.querySelectorAll("[data-rkind]").forEach(b=>b.classList.toggle("selected",b.dataset.rkind===recurringKind));openModal("recurringModal")};
document.querySelectorAll("[data-rkind]").forEach(b=>b.onclick=()=>{recurringKind=b.dataset.rkind;$("recurringKind").value=recurringKind;document.querySelectorAll("[data-rkind]").forEach(x=>x.classList.toggle("selected",x===b))});
$("recurringForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/recurring",{method:"POST",body:JSON.stringify({kind:recurringKind,amount:Number($("recurringAmount").value),category:$("recurringCategory").value,note:$("recurringNote").value,frequency:$("recurringFrequency").value,next_date:$("recurringDate").value})});closeModal("recurringModal");notify("Регулярный платёж сохранён");await refresh()}catch(err){notify(err.message)}};
$("date").value=today();document.querySelectorAll("[data-kind]").forEach(b=>b.classList.toggle("selected",b.dataset.kind===kind));$("txTitle").textContent=kind==="income"?"Новый доход":"Новый расход";openModal("txModal")}
$("addFab").onclick=()=>startTx();$("quickIncome").onclick=()=>startTx("income");$("quickExpense").onclick=()=>startTx("expense");
document.querySelectorAll("[data-kind]").forEach(b=>b.onclick=()=>{kind=b.dataset.kind;document.querySelectorAll("[data-kind]").forEach(x=>x.classList.toggle("selected",x===b));$("txTitle").textContent=kind==="income"?"Новый доход":"Новый расход";updateCategoryOptions()});
$("txForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/transactions",{method:"POST",body:JSON.stringify({kind,amount:Number($("amount").value),category:$("category").value,note:$("note").value,happened_at:$("date").value})});closeModal("txModal");await refresh();showTab("history")}catch(err){notify(err.message)}};
$("newGoal").onclick=()=>{$("goalForm").reset();openModal("goalModal")};
$("goalForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/goals",{method:"POST",body:JSON.stringify({title:$("goalTitle").value,target:Number($("goalTarget").value),saved:Number($("goalSaved").value||0),deadline:$("goalDeadline").value})});closeModal("goalModal");await refresh()}catch(err){notify(err.message)}};
$("contributeForm").onsubmit=async e=>{e.preventDefault();try{await api(`/api/goals/${$("contributeId").value}/add`,{method:"POST",body:JSON.stringify({amount:Number($("contributeAmount").value)})});closeModal("contributeModal");await refresh()}catch(err){notify(err.message)}};
$("settingsForm").onsubmit=async e=>{e.preventDefault();const data={currency:$("currency").value,needs:Number($("needs").value),wants:Number($("wants").value),savings:Number($("savings").value)};if(data.needs+data.wants+data.savings!==100){$("percentHint").textContent="Сумма процентов должна быть ровно 100%.";return}try{await api("/api/settings",{method:"PUT",body:JSON.stringify(data)});notify("Настройки бюджета сохранены");await refresh()}catch(err){notify(err.message)}};
let recurringKind="expense";
$("newRecurring").onclick=()=>{$("recurringForm").reset();recurringKind="expense";$("recurringKind").value=recurringKind;$("recurringDate").value=today();document.querySelectorAll("[data-rkind]").forEach(b=>b.classList.toggle("selected",b.dataset.rkind===recurringKind));openModal("recurringModal")};
document.querySelectorAll("[data-rkind]").forEach(b=>b.onclick=()=>{recurringKind=b.dataset.rkind;$("recurringKind").value=recurringKind;document.querySelectorAll("[data-rkind]").forEach(x=>x.classList.toggle("selected",x===b))});
$("recurringForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/recurring",{method:"POST",body:JSON.stringify({kind:recurringKind,amount:Number($("recurringAmount").value),category:$("recurringCategory").value,note:$("recurringNote").value,frequency:$("recurringFrequency").value,next_date:$("recurringDate").value})});closeModal("recurringModal");notify("Регулярный платёж сохранён");await refresh()}catch(err){notify(err.message)}};
$("date").value=today();
$("calendarMonth").value=today().slice(0,7);$("calendarMonth").onchange=()=>renderCalendar().catch(e=>notify(e.message));
$("addWallet").onclick=async()=>{const name=prompt('Название кошелька (например, Наличные)');if(!name)return;const balance=Number(prompt('Текущий остаток в ₽','0')||0);if(!Number.isFinite(balance)||balance<0){notify('Укажи корректную сумму');return}try{await api('/api/wallets',{method:'POST',body:JSON.stringify({name,kind:'cash',balance})});await renderWallets()}catch(e){notify(e.message)}};
$("addLimit").onclick=async()=>{const category=prompt('Категория расходов (должна совпадать с категорией операции)');if(!category)return;const amount=Number(prompt('Лимит на месяц, ₽'));if(!Number.isFinite(amount)||amount<=0){notify('Укажи корректный лимит');return}try{await api('/api/limits',{method:'POST',body:JSON.stringify({category,amount})});await renderLimits()}catch(e){notify(e.message)}};
$("exportData").onclick=async()=>{try{const data=await api('/api/export');const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='moneymate-backup.json';a.click();URL.revokeObjectURL(url);notify('Резервная копия скачана')}catch(e){notify(e.message)}};
function applyTheme(theme){
 document.documentElement.dataset.theme=theme||"default";
 document.querySelectorAll("[data-theme]").forEach(b=>b.classList.toggle("selected",b.dataset.theme===(theme||"default")));
}
function renderPremiumInsights(data){
 $("premiumLocked").classList.add("hidden");$("premiumContent").classList.remove("hidden");
 $("forecastExpense").textContent=money(data.forecast_expense);
 $("forecastBalance").textContent=money(data.forecast_balance);
 $("forecastDays").textContent=`Осталось дней: ${data.days_left}`;
 const alerts=$("premiumAlerts");
 alerts.innerHTML=(data.alerts||[]).map(a=>`<div class="premium-alert ${esc(a.level)}"><b>${esc(a.title)}</b><small>${esc(a.text)}</small></div>`).join("")||'<div class="premium-alert info">Пока всё спокойно. Продолжай записывать операции.</div>';
 $("premiumCategories").innerHTML=(data.categories||[]).slice(0,5).map(x=>`<div class="premium-category"><span>${esc(x.category)}</span><b>${money(x.amount)}</b></div>`).join("")||'<small class="muted">Пока недостаточно данных.</small>';
 $("premiumNotifications").checked=!!data.notifications_enabled;
 applyTheme(data.theme);
}
async function loadPremiumInsights(){
 if(!accessState||accessState.plan!=="premium")return;
 try{const d=await api("/api/premium/insights");renderPremiumInsights(d)}catch(e){if(e.message.includes("Premium"))notify(e.message);else console.warn(e)}
}
document.querySelectorAll("[data-theme]").forEach(b=>b.addEventListener("click",async()=>{
 if(!accessState||accessState.plan!=="premium"){notify("Темы доступны в Premium");return}
 const theme=b.dataset.theme;
 try{await api("/api/premium/preferences",{method:"PUT",body:JSON.stringify({theme,notifications_enabled:$("premiumNotifications").checked})});applyTheme(theme);notify("Тема обновлена")}catch(e){notify(e.message)}
}));
$("premiumNotifications").onchange=async()=>{
 try{await api("/api/premium/preferences",{method:"PUT",body:JSON.stringify({theme:document.documentElement.dataset.theme||"default",notifications_enabled:$("premiumNotifications").checked})});notify("Настройки уведомлений сохранены")}catch(e){notify(e.message);$("premiumNotifications").checked=!$("premiumNotifications").checked}
};
$("premiumUnlock").onclick=()=>purchasePremium();
async function purchasePremium(){try{const invoice=await api("/api/premium/invoice",{method:"POST",body:"{}"});if(!tg?.openInvoice){notify("Оплата доступна при открытии приложения внутри Telegram.");return}tg.openInvoice(invoice.invoice_url,async status=>{if(status==="paid"){notify("Платёж принят. Активируем Premium…");setTimeout(checkAccess,1800)}else if(status==="failed"){notify("Не удалось провести оплату. Попробуй ещё раз.")}})}catch(e){notify(e.message)}}
async function checkAccess(){
 const gate=$("accessGate"),title=$("gateTitle"),txt=$("gateText"),actions=$("gateActions");
 gate.classList.remove("hidden");
 if(!initData){title.textContent="Открой MoneyMate в Telegram";txt.textContent="Для безопасного входа запусти Mini App через своего Telegram-бота.";actions.innerHTML="";return}
 title.textContent="Проверяем доступ…";txt.textContent="Связываемся с MoneyMate. Обычно это занимает несколько секунд.";actions.innerHTML="";
 try{
  const state=await api("/api/access");accessState=state;
  if(!state.channel_member){title.textContent="Сначала подпишись на канал";txt.textContent="Подпишись на MoneyMateDiary, затем нажми «Проверить подписку».";actions.innerHTML='<button class="primary" id="joinChannel">Подписаться на канал</button><button class="secondary" id="checkChannel">Проверить подписку</button>';
   $("joinChannel").onclick=()=>tg?.openTelegramLink("https://t.me/MoneyMateDiary");$("checkChannel").onclick=checkAccess;return;
  }
  title.textContent=state.plan==="premium"?"MoneyMate Premium активен 💚":"Ты в MoneyMate!";
  txt.textContent=state.plan==="premium"?"У тебя активен Premium. Приятного использования!":"Ты используешь бесплатный тариф. Открой Premium, чтобы получить расширенные возможности.";
  actions.innerHTML=state.plan==="premium"?'<button class="primary" id="enterApp">Открыть приложение</button><p class="access-small">Premium действует до '+new Date(state.premium_expires_at*1000).toLocaleDateString("ru-RU")+'</p>':'<button class="primary" id="buyPremium">Подключить Premium · 179 ⭐ / 30 дней</button><button class="secondary" id="enterFree">Продолжить бесплатно</button>';
  if($("enterApp"))$("enterApp").onclick=()=>gate.classList.add("hidden");
  if($("enterFree"))$("enterFree").onclick=()=>gate.classList.add("hidden");
  if($("buyPremium"))$("buyPremium").onclick=purchasePremium;
  gate.classList.add("hidden");
  const premiumStatus=$("premiumStatus"),premiumBtn=$("premiumBuyHome");
  if(premiumStatus)premiumStatus.textContent=state.plan==="premium"?"Premium активен до "+new Date(state.premium_expires_at*1000).toLocaleDateString("ru-RU"):"Расширенные возможности за 179 ⭐ / 30 дней";
  if(premiumBtn){premiumBtn.textContent=state.plan==="premium"?"Premium активен ✓":"Подключить Premium · 179 ⭐";premiumBtn.disabled=state.plan==="premium";premiumBtn.onclick=purchasePremium;}
  $("premiumLocked").classList.toggle("hidden",state.plan==="premium");
  $("premiumContent").classList.toggle("hidden",state.plan!=="premium");
  $("assistantPlanLabel").textContent=state.plan==="premium"?"Включено в Premium":"Только Premium · 179 ⭐ / 30 дней";
  $("aiQuestion").disabled=state.plan!=="premium";
  $("aiForm").querySelector("button[type=submit]").disabled=state.plan!=="premium";
  $("aiAnswer").textContent=state.plan==="premium"?"Привет! Я помогу разобраться с бюджетом, расходами и накоплениями. Задай вопрос ниже.":"Личный финансовый помощник входит в Premium. Подключи Premium, чтобы получать разбор своих доходов, расходов, целей и платежей.";
  $("premiumUnlock").textContent=state.plan==="premium"?"Premium активен":"Открыть Premium · 179 ⭐";
  $("premiumUnlock").disabled=state.plan==="premium";
  await refresh();
 }catch(e){title.textContent="Не удалось проверить доступ";txt.textContent=e.message;actions.innerHTML='<button class="primary" id="retryAccess">Повторить проверку</button>';$("retryAccess").onclick=checkAccess}
}
(async()=>{if(!initData){await checkAccess();return}await checkAccess()})();

// MoneyMate AI assistant
$("aiForm").onsubmit=async e=>{e.preventDefault();const q=$("aiQuestion").value.trim();if(!q)return;const out=$("aiAnswer");out.textContent="Думаю над ответом…";const btn=$("aiForm").querySelector("button[type=submit]");btn.disabled=true;btn.textContent="Обрабатываю…";try{const result=await api("/api/assistant",{method:"POST",body:JSON.stringify({question:q})});out.textContent=result.answer;$("aiQuestion").value=""}catch(err){out.textContent=err.message;notify(err.message)}finally{btn.disabled=false;btn.textContent="Получить финансовый разбор ✦"}};
