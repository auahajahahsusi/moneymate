import os, json, sqlite3, hashlib, hmac, time, urllib.request, urllib.error
from urllib.parse import parse_qsl
from contextlib import contextmanager
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "@MoneyMateDiary")
TELEGRAM_WEBHOOK_SECRET = os.getenv("TELEGRAM_WEBHOOK_SECRET", "")
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
PREMIUM_STARS = 179
DB_PATH = os.getenv("DB_PATH", "moneymate.db")
app = FastAPI(title="MoneyMate API")

@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS subscriptions (
          user_id TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'free',
          expires_at INTEGER DEFAULT 0, telegram_charge_id TEXT DEFAULT '',
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS transactions (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
          kind TEXT NOT NULL CHECK(kind IN ('income','expense')),
          amount REAL NOT NULL, category TEXT NOT NULL, note TEXT DEFAULT '',
          happened_at TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS goals (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
          title TEXT NOT NULL, target REAL NOT NULL, saved REAL NOT NULL DEFAULT 0,
          deadline TEXT DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
          user_id TEXT PRIMARY KEY, currency TEXT NOT NULL DEFAULT 'RUB',
          needs REAL NOT NULL DEFAULT 50, wants REAL NOT NULL DEFAULT 30,
          savings REAL NOT NULL DEFAULT 20
        );
        CREATE TABLE IF NOT EXISTS wallets (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
          name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'cash', balance REAL NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS spending_limits (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
          category TEXT NOT NULL, amount REAL NOT NULL, created_at TEXT NOT NULL,
          UNIQUE(user_id, category)
        );
        CREATE TABLE IF NOT EXISTS recurring_payments (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
          kind TEXT NOT NULL CHECK(kind IN ('income','expense')),
          amount REAL NOT NULL, category TEXT NOT NULL, note TEXT DEFAULT '',
          frequency TEXT NOT NULL CHECK(frequency IN ('weekly','monthly','yearly')),
          next_date TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS payment_events (
          telegram_charge_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
          amount INTEGER NOT NULL, currency TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS premium_preferences (
          user_id TEXT PRIMARY KEY, theme TEXT NOT NULL DEFAULT 'default',
          notifications_enabled INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL
        );
        """)
init_db()

def verify_init_data(init_data: str):
    if not BOT_TOKEN:
        raise HTTPException(503, "BOT_TOKEN is not configured on the server")
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash")
        auth_date = int(pairs.get("auth_date", "0"))
        if time.time() - auth_date > 86400:
            raise ValueError("expired Telegram session")
        data_check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            raise ValueError("invalid signature")
        user = json.loads(pairs["user"])
        return str(user["id"])
    except Exception:
        raise HTTPException(401, "Open MoneyMate from your Telegram bot")

def telegram_api(method: str, payload: dict):
    if not BOT_TOKEN:
        raise HTTPException(503, "BOT_TOKEN is not configured on the server")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/{method}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            result = json.loads(response.read().decode())
        if not result.get("ok"):
            raise RuntimeError(result.get("description", "Telegram API error"))
        return result.get("result")
    except Exception as exc:
        raise HTTPException(502, f"Telegram API error: {exc}")

def is_channel_member(uid: str) -> bool:
    try:
        member = telegram_api("getChatMember", {"chat_id": REQUIRED_CHANNEL, "user_id": int(uid)})
        return member.get("status") in ("creator", "administrator", "member") or (member.get("status") == "restricted" and member.get("is_member"))
    except Exception:
        return False

def current_user(x_telegram_init_data: str = Header(default="")):
    uid = verify_init_data(x_telegram_init_data)
    if not is_channel_member(uid):
        raise HTTPException(403, "Подпишись на Telegram-канал MoneyMate, чтобы пользоваться приложением")
    return uid

FREE_LIMITS = {"wallets": 2, "goals": 3, "budgets": 3}

def is_premium(uid: str) -> bool:
    with db() as c:
        row = c.execute("SELECT status, expires_at FROM subscriptions WHERE user_id=?", (uid,)).fetchone()
    return bool(row and row["status"] == "premium" and int(row["expires_at"] or 0) > int(time.time()))

def require_premium(uid: str):
    if not is_premium(uid):
        raise HTTPException(403, "Эта возможность доступна в MoneyMate Premium. Подключи Premium за 179 ⭐ на 30 дней.")

def enforce_free_limit(uid: str, table: str, label: str):
    if is_premium(uid):
        return
    maximum = FREE_LIMITS[table]
    with db() as c:
        count = c.execute(f"SELECT COUNT(*) FROM {table if table != 'budgets' else 'spending_limits'} WHERE user_id=?", (uid,)).fetchone()[0]
    if count >= maximum:
        raise HTTPException(403, f"На бесплатном тарифе доступно до {maximum} {label}. Premium снимает ограничение.")

class TransactionIn(BaseModel):
    kind: str
    amount: float = Field(gt=0, le=100000000)
    category: str = Field(min_length=1, max_length=40)
    note: str = Field(default="", max_length=160)
    happened_at: str

class GoalIn(BaseModel):
    title: str = Field(min_length=1, max_length=60)
    target: float = Field(gt=0, le=100000000)
    saved: float = Field(default=0, ge=0)
    deadline: str = ""

class GoalAdd(BaseModel):
    amount: float = Field(gt=0)

class RecurringIn(BaseModel):
    kind: str
    amount: float = Field(gt=0, le=100000000)
    category: str = Field(min_length=1, max_length=40)
    note: str = Field(default="", max_length=160)
    frequency: str
    next_date: str

class SettingsIn(BaseModel):
    currency: str = "RUB"
    needs: float = Field(ge=0, le=100)
    wants: float = Field(ge=0, le=100)
    savings: float = Field(ge=0, le=100)

@app.on_event("startup")
async def register_telegram_webhook():
    if BOT_TOKEN and PUBLIC_BASE_URL and TELEGRAM_WEBHOOK_SECRET:
        try:
            telegram_api("setWebhook", {
                "url": PUBLIC_BASE_URL + "/api/telegram/webhook",
                "secret_token": TELEGRAM_WEBHOOK_SECRET,
                "allowed_updates": ["message", "pre_checkout_query"],
            })
        except Exception as exc:
            print(f"Telegram webhook registration failed: {exc}")

@app.get("/api/access")
def access(x_telegram_init_data: str = Header(default="")):
    uid = verify_init_data(x_telegram_init_data)
    member = is_channel_member(uid)
    with db() as c:
        row = c.execute("SELECT * FROM subscriptions WHERE user_id=?", (uid,)).fetchone()
        if row and row["status"] == "premium" and row["expires_at"] and row["expires_at"] <= int(time.time()):
            c.execute("UPDATE subscriptions SET status='free' WHERE user_id=?", (uid,))
            row = c.execute("SELECT * FROM subscriptions WHERE user_id=?", (uid,)).fetchone()
    premium = bool(row and row["status"] == "premium" and row["expires_at"] > int(time.time()))
    return {"channel_member": member, "channel": REQUIRED_CHANNEL, "plan": "premium" if premium else "free", "premium_expires_at": row["expires_at"] if premium else None, "stars_price": PREMIUM_STARS}

@app.post("/api/premium/invoice")
def premium_invoice(x_telegram_init_data: str = Header(default="")):
    uid = verify_init_data(x_telegram_init_data)
    if not is_channel_member(uid):
        raise HTTPException(403, "Сначала подпишись на канал MoneyMate")
    payload = f"moneymate_premium:{uid}:{int(time.time())}"
    link = telegram_api("createInvoiceLink", {
        "title": "MoneyMate Premium",
        "description": "Доступ к расширенным возможностям MoneyMate на 30 дней",
        "payload": payload,
        "provider_token": "",
        "currency": "XTR",
        "prices": [{"label": "MoneyMate Premium · 30 дней", "amount": PREMIUM_STARS}],
        "subscription_period": 2592000,
    })
    return {"invoice_url": link, "stars": PREMIUM_STARS}

@app.post("/api/telegram/webhook")
def telegram_webhook(update: dict, x_telegram_bot_api_secret_token: str = Header(default="")):
    if not TELEGRAM_WEBHOOK_SECRET:
        raise HTTPException(503, "TELEGRAM_WEBHOOK_SECRET is not configured")
    if not hmac.compare_digest(x_telegram_bot_api_secret_token, TELEGRAM_WEBHOOK_SECRET):
        raise HTTPException(403, "Invalid webhook secret")
    if "pre_checkout_query" in update:
        query = update["pre_checkout_query"]
        payload = str(query.get("invoice_payload", ""))
        parts = payload.split(":")
        valid = (len(parts) == 3 and parts[0] == "moneymate_premium"
                 and str(query.get("from", {}).get("id", "")) == parts[1]
                 and query.get("currency") == "XTR"
                 and int(query.get("total_amount", 0)) == PREMIUM_STARS)
        telegram_api("answerPreCheckoutQuery", {
            "pre_checkout_query_id": query["id"], "ok": valid,
            **({"error_message": "Счёт MoneyMate Premium недействителен. Создай новый счёт."} if not valid else {})
        })
        return {"ok": True}
    message = update.get("message") or update.get("edited_message") or {}
    
      
    text = message.get("text", "")
    command = text.split(maxsplit=1)[0].split("@")[0] if text.split() else ""

    if command == "/start":
        web_app_url = PUBLIC_BASE_URL or "https://moneymate-1g70.onrender.com"

        telegram_api("sendMessage", {
            "chat_id": message["chat"]["id"],
            "text": (
                "👋 Добро пожаловать в MoneyMate!\n\n"
                "Твой личный помощник в управлении финансами 💚\n\n"
                "💸 Учитывай доходы и расходы.\n"
                "🎯 Копи на свои цели.\n"
                "📊 Контролируй бюджет.\n"
                "👑 Открывай дополнительные возможности с Premium.\n\n"
                "Готов взять свои деньги под контроль?"
            ),
            "reply_markup": {
                "inline_keyboard": [[
                    {
                        "text": "💚 Открыть MoneyMate",
                        "web_app": {"url": web_app_url}
                    }
                ]]
            }
        })
        return {"ok": True}
    
    payment = message.get("successful_payment")
    if payment:

        payload = payment.get("invoice_payload", "")
        parts = payload.split(":")
        if len(parts) != 3 or parts[0] != "moneymate_premium":
            return {"ok": True}
        uid = parts[1]
        if str(message.get("from", {}).get("id", "")) != uid or payment.get("currency") != "XTR" or int(payment.get("total_amount", 0)) != PREMIUM_STARS:
            raise HTTPException(400, "Payment payload mismatch")
        charge_id = payment.get("telegram_payment_charge_id", "")
        if not charge_id:
            raise HTTPException(400, "Missing Telegram payment charge id")
        expiry = int(payment.get("subscription_expiration_date") or (int(time.time()) + 2592000))
        now = datetime.now(timezone.utc).isoformat()
        with db() as c:
            # Telegram may retry webhook delivery. A charge is applied only once.
            already = c.execute("SELECT 1 FROM payment_events WHERE telegram_charge_id=?", (charge_id,)).fetchone()
            if not already:
                c.execute("INSERT INTO payment_events(telegram_charge_id,user_id,amount,currency,created_at) VALUES(?,?,?,?,?)",
                          (charge_id, uid, int(payment.get("total_amount", 0)), payment.get("currency", ""), now))
                c.execute("INSERT INTO subscriptions(user_id,status,expires_at,telegram_charge_id,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET status='premium',expires_at=MAX(subscriptions.expires_at,excluded.expires_at),telegram_charge_id=excluded.telegram_charge_id,updated_at=excluded.updated_at",
                          (uid, "premium", expiry, charge_id, now))
    return {"ok": True}

@app.get("/api/health")
def health():
    return {"ok": True, "app": "MoneyMate"}

@app.get("/api/me")
def me(user_id: str = Header(default="", alias="X-Telegram-Init-Data")):
    uid = current_user(user_id)
    with db() as c:
        row = c.execute("SELECT * FROM settings WHERE user_id=?", (uid,)).fetchone()
        if not row:
            c.execute("INSERT INTO settings(user_id) VALUES(?)", (uid,))
            row = c.execute("SELECT * FROM settings WHERE user_id=?", (uid,)).fetchone()
    return {"user_id": uid, "settings": dict(row)}

@app.get("/api/transactions")
def transactions(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        rows = c.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY happened_at DESC, id DESC LIMIT 300", (uid,)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/transactions")
def add_transaction(data: TransactionIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    if data.kind not in ("income", "expense"):
        raise HTTPException(400, "Invalid transaction kind")
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        cur = c.execute("INSERT INTO transactions(user_id,kind,amount,category,note,happened_at,created_at) VALUES(?,?,?,?,?,?,?)",
          (uid, data.kind, data.amount, data.category.strip(), data.note.strip(), data.happened_at, now))
        row = c.execute("SELECT * FROM transactions WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)

@app.delete("/api/transactions/{transaction_id}")
def delete_transaction(transaction_id: int, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        cur = c.execute("DELETE FROM transactions WHERE id=? AND user_id=?", (transaction_id, uid))
    if not cur.rowcount:
        raise HTTPException(404, "Transaction not found")
    return {"ok": True}

@app.get("/api/goals")
def goals(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        rows = c.execute("SELECT * FROM goals WHERE user_id=? ORDER BY id DESC", (uid,)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/goals")
def add_goal(data: GoalIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    enforce_free_limit(uid, "goals", "целей")
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        cur = c.execute("INSERT INTO goals(user_id,title,target,saved,deadline,created_at) VALUES(?,?,?,?,?,?)",
          (uid, data.title.strip(), data.target, data.saved, data.deadline, now))
        row = c.execute("SELECT * FROM goals WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)

@app.post("/api/goals/{goal_id}/add")
def contribute(goal_id: int, data: GoalAdd, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        cur = c.execute("UPDATE goals SET saved=saved+? WHERE id=? AND user_id=?", (data.amount, goal_id, uid))
        if not cur.rowcount:
            raise HTTPException(404, "Goal not found")
        row = c.execute("SELECT * FROM goals WHERE id=?", (goal_id,)).fetchone()
    return dict(row)

@app.delete("/api/goals/{goal_id}")
def delete_goal(goal_id: int, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        cur = c.execute("DELETE FROM goals WHERE id=? AND user_id=?", (goal_id, uid))
    if not cur.rowcount:
        raise HTTPException(404, "Goal not found")
    return {"ok": True}

def advance_date(date_text: str, frequency: str) -> str:
    from datetime import date, timedelta
    from calendar import monthrange
    d = date.fromisoformat(date_text)
    if frequency == "weekly":
        d += timedelta(days=7)
    elif frequency == "yearly":
        try:
            d = d.replace(year=d.year + 1)
        except ValueError:
            d = d.replace(year=d.year + 1, day=28)
    else:
        month = d.month + 1
        year = d.year + (month - 1) // 12
        month = (month - 1) % 12 + 1
        d = d.replace(year=year, month=month, day=min(d.day, monthrange(year, month)[1]))
    return d.isoformat()

def process_due_payments(uid: str):
    today = datetime.now().date().isoformat()
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        rows = c.execute("SELECT * FROM recurring_payments WHERE user_id=? AND active=1 AND next_date<=?", (uid, today)).fetchall()
        for item in rows:
            next_date = item["next_date"]
            # Catch up every missed occurrence exactly once when the user opens the app.
            for _ in range(120):
                if next_date > today:
                    break
                c.execute("INSERT INTO transactions(user_id,kind,amount,category,note,happened_at,created_at) VALUES(?,?,?,?,?,?,?)",
                    (uid, item["kind"], item["amount"], item["category"], item["note"], next_date, now))
                next_date = advance_date(next_date, item["frequency"])
            c.execute("UPDATE recurring_payments SET next_date=? WHERE id=? AND user_id=?", (next_date, item["id"], uid))

@app.get("/api/recurring")
def list_recurring(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    process_due_payments(uid)
    with db() as c:
        rows = c.execute("SELECT * FROM recurring_payments WHERE user_id=? ORDER BY active DESC,next_date ASC,id DESC", (uid,)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/recurring")
def add_recurring(data: RecurringIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    if data.kind not in ("income", "expense") or data.frequency not in ("weekly", "monthly", "yearly"):
        raise HTTPException(400, "Invalid recurring payment settings")
    try:
        datetime.strptime(data.next_date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(400, "Invalid next date")
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        cur = c.execute("INSERT INTO recurring_payments(user_id,kind,amount,category,note,frequency,next_date,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (uid, data.kind, data.amount, data.category.strip(), data.note.strip(), data.frequency, data.next_date, now))
        row = c.execute("SELECT * FROM recurring_payments WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)

@app.patch("/api/recurring/{payment_id}")
def toggle_recurring(payment_id: int, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        c.execute("UPDATE recurring_payments SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=? AND user_id=?", (payment_id, uid))
        row = c.execute("SELECT * FROM recurring_payments WHERE id=? AND user_id=?", (payment_id, uid)).fetchone()
    if not row:
        raise HTTPException(404, "Recurring payment not found")
    return dict(row)

@app.delete("/api/recurring/{payment_id}")
def delete_recurring(payment_id: int, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        cur = c.execute("DELETE FROM recurring_payments WHERE id=? AND user_id=?", (payment_id, uid))
    if not cur.rowcount:
        raise HTTPException(404, "Recurring payment not found")
    return {"ok": True}

class WalletIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    kind: str = Field(default="cash", max_length=20)
    balance: float = Field(default=0, ge=0, le=100000000)

class LimitIn(BaseModel):
    category: str = Field(min_length=1, max_length=40)
    amount: float = Field(gt=0, le=100000000)

@app.get("/api/wallets")
def get_wallets(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM wallets WHERE user_id=? ORDER BY id", (uid,)).fetchall()]

@app.post("/api/wallets")
def create_wallet(data: WalletIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    enforce_free_limit(uid, "wallets", "кошельков")
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        cur = c.execute("INSERT INTO wallets(user_id,name,kind,balance,created_at) VALUES(?,?,?,?,?)", (uid,data.name.strip(),data.kind,data.balance,now))
        return dict(c.execute("SELECT * FROM wallets WHERE id=?", (cur.lastrowid,)).fetchone())

@app.delete("/api/wallets/{wallet_id}")
def remove_wallet(wallet_id: int, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        cur = c.execute("DELETE FROM wallets WHERE id=? AND user_id=?", (wallet_id,uid))
    if not cur.rowcount: raise HTTPException(404, "Wallet not found")
    return {"ok":True}

@app.get("/api/limits")
def get_limits(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    month = datetime.now().strftime("%Y-%m")
    with db() as c:
        rows = c.execute("SELECT l.*, COALESCE((SELECT SUM(t.amount) FROM transactions t WHERE t.user_id=l.user_id AND t.category=l.category AND t.kind='expense' AND substr(t.happened_at,1,7)=?),0) spent FROM spending_limits l WHERE l.user_id=? ORDER BY l.category", (month,uid)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/limits")
def save_limit(data: LimitIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        exists = c.execute("SELECT 1 FROM spending_limits WHERE user_id=? AND category=?", (uid, data.category.strip())).fetchone()
    if not exists:
        enforce_free_limit(uid, "budgets", "лимитов")
    with db() as c:
        c.execute("INSERT INTO spending_limits(user_id,category,amount,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id,category) DO UPDATE SET amount=excluded.amount", (uid,data.category.strip(),data.amount,datetime.now(timezone.utc).isoformat()))
    return {"ok":True}

@app.delete("/api/limits/{limit_id}")
def delete_limit(limit_id: int, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        cur = c.execute("DELETE FROM spending_limits WHERE id=? AND user_id=?", (limit_id,uid))
    if not cur.rowcount: raise HTTPException(404, "Limit not found")
    return {"ok":True}

@app.get("/api/calendar")
def calendar_events(month: str = "", x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    if not month: month = datetime.now().strftime("%Y-%m")
    if len(month)!=7 or month[4]!='-': raise HTTPException(400,"Month must be YYYY-MM")
    with db() as c:
        tx = c.execute("SELECT id,kind,amount,category,happened_at AS date,note FROM transactions WHERE user_id=? AND substr(happened_at,1,7)=? ORDER BY happened_at",(uid,month)).fetchall()
        rp = c.execute("SELECT id,kind,amount,category,next_date AS date,note,frequency FROM recurring_payments WHERE user_id=? AND active=1 AND substr(next_date,1,7)=? ORDER BY next_date",(uid,month)).fetchall()
    return {"month":month,"events":[dict(r,source="operation") for r in tx]+[dict(r,source="planned") for r in rp]}

@app.get("/api/export")
def export_data(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        result={}
        for table in ("transactions","goals","settings","recurring_payments","wallets","spending_limits"):
            result[table]=[dict(r) for r in c.execute(f"SELECT * FROM {table} WHERE user_id=?",(uid,)).fetchall()]
    return {"exported_at":datetime.now(timezone.utc).isoformat(),"currency":"RUB","data":result}

@app.get("/api/settings")
def get_settings(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    with db() as c:
        row = c.execute("SELECT * FROM settings WHERE user_id=?", (uid,)).fetchone()
        if not row:
            c.execute("INSERT INTO settings(user_id) VALUES(?)", (uid,))
            row = c.execute("SELECT * FROM settings WHERE user_id=?", (uid,)).fetchone()
    return dict(row)

@app.put("/api/settings")
def save_settings(data: SettingsIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    if abs(data.needs + data.wants + data.savings - 100) > 0.01:
        raise HTTPException(400, "Budget percentages must total 100")
    with db() as c:
        c.execute("INSERT INTO settings(user_id,currency,needs,wants,savings) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET currency=excluded.currency,needs=excluded.needs,wants=excluded.wants,savings=excluded.savings",
          (uid, "RUB", data.needs, data.wants, data.savings))
    return {"ok": True}

@app.get("/api/summary")
def summary(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    month = datetime.now().strftime("%Y-%m")
    with db() as c:
        rows = c.execute("SELECT kind, SUM(amount) total FROM transactions WHERE user_id=? AND substr(happened_at,1,7)=? GROUP BY kind", (uid, month)).fetchall()
        cats = c.execute("SELECT category, SUM(amount) total FROM transactions WHERE user_id=? AND kind='expense' AND substr(happened_at,1,7)=? GROUP BY category ORDER BY total DESC", (uid, month)).fetchall()
        settings = c.execute("SELECT * FROM settings WHERE user_id=?", (uid,)).fetchone()
        if not settings:
            c.execute("INSERT INTO settings(user_id) VALUES(?)", (uid,))
            settings = c.execute("SELECT * FROM settings WHERE user_id=?", (uid,)).fetchone()
    totals = {r["kind"]: r["total"] or 0 for r in rows}
    income, expense = totals.get("income", 0), totals.get("expense", 0)
    balance = income - expense
    # Transparent 1-100 wellness indicator, not a credit score or financial advice.
    if income <= 0:
        score = 1
        score_parts = {"сбережения": 0, "баланс": 0, "расходы": 0, "резерв": 0}
        score_hint = "Добавь доходы и расходы, чтобы оценка стала точнее."
    else:
        savings_rate = max(0, balance / income)
        savings_points = min(30, savings_rate / 0.20 * 30)
        balance_points = 25 if balance >= 0 else max(0, 25 * (1 + balance / income))
        ratio = expense / income
        spending_points = 25 if ratio <= 0.5 else (25 * max(0, (1-ratio)/0.5) if ratio < 1 else 0)
        with db() as c:
            reserve = c.execute("SELECT COALESCE(SUM(saved),0) FROM goals WHERE user_id=? AND (lower(title) LIKE '%резерв%' OR lower(title) LIKE '%подушк%')", (uid,)).fetchone()[0]
        reserve_points = min(20, reserve / max(expense * 3, 1) * 20) if expense > 0 else (20 if reserve > 0 else 0)
        raw_score = savings_points + balance_points + spending_points + reserve_points
        score = max(1, min(100, round(raw_score)))
        score_parts = {"сбережения": round(savings_points), "баланс": round(balance_points), "расходы": round(spending_points), "резерв": round(reserve_points)}
        score_hint = "Создай цель «Финансовая подушка» и пополняй её, чтобы улучшить оценку." if reserve_points < 20 else "Продолжай поддерживать положительный баланс."
    return {"income": income, "expense": expense, "balance": balance,
      "categories": [dict(r) for r in cats], "settings": dict(settings), "month": month,
      "financial_health": {"score": score, "parts": score_parts, "hint": score_hint}}

@app.get("/api/premium/insights")
def premium_insights(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    require_premium(uid)
    today = datetime.now().date()
    month = today.strftime("%Y-%m")
    days_in_month = __import__("calendar").monthrange(today.year, today.month)[1]
    days_left = max(1, days_in_month - today.day + 1)
    with db() as c:
        tx = [dict(r) for r in c.execute(
            "SELECT kind,amount,category,happened_at FROM transactions WHERE user_id=? AND substr(happened_at,1,7)=?",
            (uid, month)).fetchall()]
        limits = [dict(r) for r in c.execute(
            "SELECT l.category,l.amount,COALESCE(SUM(t.amount),0) spent FROM spending_limits l LEFT JOIN transactions t ON t.user_id=l.user_id AND t.category=l.category AND t.kind='expense' AND substr(t.happened_at,1,7)=? WHERE l.user_id=? GROUP BY l.id",
            (month, uid)).fetchall()]
        prefs = c.execute("SELECT * FROM premium_preferences WHERE user_id=?", (uid,)).fetchone()
    income = sum(float(x["amount"]) for x in tx if x["kind"] == "income")
    expense = sum(float(x["amount"]) for x in tx if x["kind"] == "expense")
    spent_daily = expense / max(1, today.day)
    forecast = spent_daily * days_in_month
    remaining = income - expense
    categories = {}
    for item in tx:
        if item["kind"] == "expense":
            categories[item["category"]] = categories.get(item["category"], 0) + float(item["amount"])
    alerts = []
    for limit in limits:
        pct = (float(limit["spent"]) / max(float(limit["amount"]), 0.01)) * 100
        if pct >= 100:
            alerts.append({"level":"danger","title":f"Лимит «{limit['category']}» превышен","text":f"Потрачено {pct:.0f}% месячного лимита."})
        elif pct >= 80:
            alerts.append({"level":"warning","title":f"Лимит «{limit['category']}» почти исчерпан","text":f"Использовано {pct:.0f}% лимита."})
    if income > 0 and forecast > income:
        alerts.append({"level":"warning","title":"Расходы могут превысить доходы","text":"При текущем темпе прогноз расходов выше дохода за месяц."})
    if not tx:
        alerts.append({"level":"info","title":"Добавь операции","text":"Когда появятся данные, здесь будут прогноз и персональные финансовые сигналы."})
    theme = prefs["theme"] if prefs else "default"
    notifications_enabled = bool(prefs["notifications_enabled"]) if prefs else True
    return {
        "month": month, "income": round(income,2), "expense": round(expense,2),
        "remaining": round(remaining,2), "forecast_expense": round(forecast,2),
        "forecast_balance": round(income-forecast,2), "days_left": days_left,
        "categories": [{"category":k,"amount":round(v,2)} for k,v in sorted(categories.items(), key=lambda kv:kv[1], reverse=True)],
        "alerts": alerts, "theme": theme, "notifications_enabled": notifications_enabled,
    }

class PremiumPreferencesIn(BaseModel):
    theme: str = Field(default="default", pattern="^(default|emerald|blackgold|purple)$")
    notifications_enabled: bool = True

@app.get("/api/premium/preferences")
def get_premium_preferences(x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    require_premium(uid)
    with db() as c:
        row = c.execute("SELECT * FROM premium_preferences WHERE user_id=?", (uid,)).fetchone()
        if not row:
            c.execute("INSERT INTO premium_preferences(user_id,updated_at) VALUES(?,?)", (uid, datetime.now(timezone.utc).isoformat()))
            row = c.execute("SELECT * FROM premium_preferences WHERE user_id=?", (uid,)).fetchone()
    return {"theme":row["theme"], "notifications_enabled":bool(row["notifications_enabled"])}

@app.put("/api/premium/preferences")
def save_premium_preferences(data: PremiumPreferencesIn, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    require_premium(uid)
    with db() as c:
        c.execute("INSERT INTO premium_preferences(user_id,theme,notifications_enabled,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET theme=excluded.theme,notifications_enabled=excluded.notifications_enabled,updated_at=excluded.updated_at",
                  (uid,data.theme,int(data.notifications_enabled),datetime.now(timezone.utc).isoformat()))
    return {"ok":True, "theme":data.theme, "notifications_enabled":data.notifications_enabled}

@app.get("/")
def index():
    return FileResponse("static/index.html")

app.mount("/static", StaticFiles(directory="static"), name="static")


class AIQuestion(BaseModel):
    question: str = Field(min_length=2, max_length=1200)

@app.post("/api/assistant")
def financial_assistant(data: AIQuestion, x_telegram_init_data: str = Header(default="")):
    uid = current_user(x_telegram_init_data)
    require_premium(uid)
    question = data.question.lower()
    month = datetime.now().strftime("%Y-%m")
    with db() as c:
        tx = [dict(r) for r in c.execute("SELECT kind, amount, category, happened_at FROM transactions WHERE user_id=? AND substr(happened_at,1,7)=?", (uid, month)).fetchall()]
        goals = [dict(r) for r in c.execute("SELECT title,target,saved,deadline FROM goals WHERE user_id=?", (uid,)).fetchall()]
        wallets = [dict(r) for r in c.execute("SELECT name,kind,balance FROM wallets WHERE user_id=?", (uid,)).fetchall()]
        recurring = [dict(r) for r in c.execute("SELECT kind,amount,category,next_date,frequency FROM recurring_payments WHERE user_id=? AND active=1 ORDER BY next_date", (uid,)).fetchall()]
    income = sum(x["amount"] for x in tx if x["kind"] == "income")
    expense = sum(x["amount"] for x in tx if x["kind"] == "expense")
    balance = income - expense
    cats = {}
    for x in tx:
        if x["kind"] == "expense": cats[x["category"]] = cats.get(x["category"], 0) + x["amount"]
    top = sorted(cats.items(), key=lambda x: x[1], reverse=True)
    money = lambda n: f"{n:,.0f}".replace(",", " ") + " ₽"
    if any(w in question for w in ("категор", "трачу", "расход", "куда уход")):
        answer = ("Расходы за этот месяц: " + "; ".join(f"{k} — {money(v)}" for k,v in top[:5]) + f". Самая затратная категория — {top[0][0]}.") if top else "Пока нет записанных расходов за этот месяц. Добавь операции, и я покажу разбивку."
    elif any(w in question for w in ("кошел", "карта", "налич", "остат")):
        answer = f"В кошельках указано {money(sum(w['balance'] for w in wallets))}. " + ("; ".join(f"{w['name']}: {money(w['balance'])}" for w in wallets) if wallets else "Кошельки пока не добавлены.")
    elif any(w in question for w in ("накоп", "собрать", "отлож")) and any(ch.isdigit() for ch in question):
        import re, math
        nums=re.findall(r"\d[\d\s]*(?:[.,]\d+)?", question)
        target=float(nums[0].replace(" ","").replace(",",".")) if nums else 0
        target=max(0,target)
        month_match=re.search(r"за\s+(\d+)\s*(?:мес|месяц|месяца|месяцев)", question)
        year_match=re.search(r"за\s+(\d+)\s*(?:год|года|лет)", question)
        months=int(month_match.group(1)) if month_match else (int(year_match.group(1))*12 if year_match else 0)
        if target:
            current_saved=sum(float(g["saved"]) for g in goals)
            remaining=max(0,target-current_saved)
            surplus=max(0,balance)
            if months:
                monthly=remaining/months
                weekly=monthly*12/52
                feasible=monthly<=surplus if income>0 else False
                answer=f"Чтобы накопить {money(target)}, осталось собрать {money(remaining)}. За {months} мес. откладывай примерно {money(monthly)} в месяц (около {money(weekly)} в неделю). "
                answer += (f"По текущему месяцу после расходов осталось {money(surplus)} — такой план выглядит достижимым, если доходы и расходы будут похожими." if feasible else f"Сейчас разница доходов и расходов за месяц — {money(balance)}. Нужно сократить расходы или увеличить срок/доход: запланированная сумма пока выше текущего свободного остатка.")
            else:
                monthly=max(1,surplus)
                estimate=math.ceil(remaining/monthly) if surplus>0 else 0
                answer=f"Цель — {money(target)}. Уже накоплено в целях: {money(current_saved)}, осталось {money(remaining)}. "
                answer += (f"При текущем свободном остатке около {money(surplus)} в месяц можно ориентироваться примерно на {estimate} мес. Откладывай эту сумму каждый месяц." if estimate else "Пока по данным этого месяца свободного остатка нет. Начни с небольшого регулярного взноса и попробуй снизить одну-две категории расходов.")
        else:
            answer="Напиши сумму, которую хочешь накопить, например: «Как накопить 50 000 рублей за 6 месяцев?»"
    elif any(w in question for w in ("цель", "накоп", "собрать", "отлож")):
        answer = ("Твои цели: " + "; ".join(f"{g['title']} — {money(g['saved'])} из {money(g['target'])} ({min(100,round(g['saved']/g['target']*100))}%)" for g in goals) + ". Пополняй их регулярно, не забывая о резерве.") if goals else "Пока целей нет. Могу рассчитать план накопления — напиши сумму и желаемый срок, например: «Как накопить 50 000 рублей за 6 месяцев?»"
    elif any(w in question for w in ("платеж", "подпис", "обязатель", "когда")):
        answer = ("Ближайшие регулярные платежи: " + "; ".join(f"{r['category']} — {money(r['amount'])}, дата {r['next_date']}" for r in recurring[:6])) if recurring else "Активных регулярных платежей пока нет. Добавь их в разделе «Платежи»."
    elif any(w in question for w in ("могу потратить", "до конца месяца", "сколько потратить", "бюджет")):
        import calendar
        days = calendar.monthrange(datetime.now().year, datetime.now().month)[1] - datetime.now().day + 1
        daily = max(0, balance) / max(days, 1)
        answer = f"За месяц доходы — {money(income)}, расходы — {money(expense)}, разница — {money(balance)}. До конца месяца {days} дн. Ориентир по текущему остатку — до {money(daily)} в день, если новых доходов и обязательных расходов не будет."
    else:
        score = 1 if income <= 0 else max(1, min(100, round(min(30,max(0,balance/income)/.2*30) + (25 if balance>=0 else max(0,25*(1+balance/income))) + (25 if expense/income<=.5 else (25*max(0,(1-expense/income)/.5) if expense/income<1 else 0)))))
        answer = f"Сводка за месяц: доходы — {money(income)}, расходы — {money(expense)}, остаток — {money(balance)}. Ориентировочное финансовое здоровье — {score}/100. Спроси меня о расходах по категориям, кошельках, целях или платежах."
    return {"answer": answer, "mode": "local"}
